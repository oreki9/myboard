package com.example.sqlite_10340_ricky;

import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import static com.example.sqlite_10340_ricky.DatabaseHelper.TABLE_NAME;
public class MainActivity extends AppCompatActivity {
    EditText xnim;
    EditText xnama;
    RadioButton Laki;
    RadioButton Perempuan;
    EditText xtgllahir;
    EditText xalamt;
    EditText xkota;
    String Kelamin;
    Button tblAdd;
    Button tblView;
    DatabaseHelper BantuDb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BantuDb=new DatabaseHelper(this);
        xnim=(EditText)findViewById(R.id.xnim);
        xnama=(EditText)findViewById(R.id.xnama);
        xtgllahir=(EditText)findViewById(R.id.xtgllahir);
        xalamt=(EditText)findViewById(R.id.xalamt);
        xkota=(EditText)findViewById(R.id.xkota);
        tblAdd=(Button)findViewById(R.id.tblAdd);
        tblView=(Button)findViewById(R.id.tblView);
        viewAll();
        tblAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean isInserted = BantuDb.insertData(xnim.getText().toString(),xnama.getText().toString(),xtgllahir.getText().toString(),Kelamin,xalamt.getText().toString(),xkota.getText().toString());
                if(isInserted == true)
                    Toast.makeText(MainActivity.this,"Data Terimpan",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(MainActivity.this,"Data Gagal Tersimpan",Toast.LENGTH_LONG).show();
            }
        });
    }
    public void viewAll() {
        tblView.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Cursor res =BantuDb.getAllData();
                        if (res.getCount() == 0) {
                            // show message
                            showMessage("Error", "Noting Found");
                            return;
                        }
                        StringBuffer buffer = new
                                StringBuffer();
                        while (res.moveToNext()) {
                            buffer.append("Nim :" +
                                    res.getString(0) + "\n");
                            buffer.append("Nama Mahasiswa :" +
                                    res.getString(1) + "\n");
                            buffer.append("TglLahir :" +
                                    res.getString(2) + "\n");
                            buffer.append("JenisKlmn :" +
                                    res.getString(3) + "\n");
                            buffer.append("Alamat :" +
                                    res.getString(4) + "\n");
                            buffer.append("Kota :" +
                                    res.getString(5) + "\n");
                        }
// show all data
                        showMessage("Mahasiswa :",
                                buffer.toString());
                    }
                });
    }
    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.Laki:
                if (checked)
                    Kelamin = "Laki-Laki";
                    break;
            case R.id.Perempuan:
                if (checked)
                    Kelamin = "Perempuan";
                    break;
        }
    }
    public void showMessage(String title, String Message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }
}