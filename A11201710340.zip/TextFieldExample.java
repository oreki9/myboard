import java.awt.*;
import java.awt.event.*;
class TextFieldExample extends Frame implements ActionListener{  
	public static void main(String args[]){
		new TextFieldExample();
	}
	Button hitung;
	TextField t1,t2,t3,t4;
	Label nim,lblnama,lblnim,lblberat,lbltinggi;
	TextFieldExample(){
		Frame f= new Frame("eki muhammad zain");
		nim = new Label("mynim");
		nim.setBounds(30,50,100,30);
		nim.setText("A11.2017.10362");
		lblnama = new Label("nim");
		lblnama.setBounds(30,100,40,30);
		lblnama.setText("nim");
		lblnim = new Label("nama");
		lblnim.setBounds(30,150,40,30);
		lblnim.setText("Nama");
		lblberat = new Label("berat");
		lblberat.setBounds(30,200,40,30);
		lblberat.setText("berat");
		lbltinggi = new Label("tinggi");
		lbltinggi.setBounds(30,250,40,30);
		lbltinggi.setText("tinggi");
		t1=new TextField();
		t1.setBounds(100,100, 200,30);  
		t2=new TextField();  
		t2.setBounds(100,150, 200,30);
		t3=new TextField();  
		t3.setBounds(100,200, 200,30);
		t4=new TextField();  
		t4.setBounds(100,250, 200,30);
		hitung = new Button("Hitung");
		hitung.setActionCommand("Ok");
		hitung.setBounds(100,300, 200,30);
		hitung.addActionListener(this);
		f.add(hitung);
		f.add(nim);
		f.add(t1);
		f.add(t2);
		f.add(t3);
		f.add(t4);
		f.add(lblnama);
		f.add(lblnim);
		f.add(lblberat);
		f.add(lbltinggi);
		f.setSize(400,400);  
		f.setLayout(null);
		f.setVisible(true);
		f.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});
	}
	public void actionPerformed(ActionEvent e)
	{
		String com = e.getActionCommand();
		if(com.equals("Ok"))
		{
			String s1=t3.getText();  
			String s2=t4.getText();
			String s3=t1.getText();
			String s4=t2.getText();
			double a=Double.parseDouble(s1);  
			double b=Double.parseDouble(s2);
			b = b*b;
			double c=a/b;
			if(c<16.5){
				System.out.println(s3+","+s4+" kurus atau ideal");
			}else if(c<25){
				System.out.println(s3+","+s4+" normal atau ideal");
			}else if(c<30){
				System.out.println(s3+","+s4+" Overweight atau tidak ideal");
			}else{
				System.out.println(s3+","+s4+" Obesitas atau tidak ideal");
			}
			String result=String.valueOf(c);
			System.out.println(c);
		}
	}
}  