// Copyright (c) 2012 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

'use strict';


function klik(e,i) {
	if(i==0){
		chrome.tabs.executeScript(null,
		{code:"document.getElementsByTagName('script')["+e+"].innerHTML"},receiveText);
	}
}
function receiveText(resultsArray){
    var str = resultsArray[0];
	str = str.substring(document.getElementById('NakanoNaka1').value, document.getElementById('NakanoNaka2').value);
	document.getElementById("naka").innerHTML = str;
}
function click() {
	var nakami = document.getElementById('NakanoNaka3').value;
	var mode = document.getElementById('NakanoNaka4').value;
	klik(nakami,mode);
}
document.addEventListener('DOMContentLoaded', function () {
  var divs = document.querySelectorAll('button');
  divs[0].addEventListener('click', click);
});