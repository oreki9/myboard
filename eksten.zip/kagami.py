from PIL import Image
from numpy import array
import numpy as np

i = Image.open('D:/projek/images/sum.jpg')
iar = np.array(i)
o = iar.tolist()
print iar[i.height-1][i.width-1]
j = Image.fromarray(o)
j.save('pol.png')