<?php
$hed = array(
	'http' => array(
		'method' => "GET",
		'header' => "Accept-Language: en-US,en;q=0.9\r\n" .
					"Cache-Control: max-age=0\r\n".
					"Cookie: foo=bar\r\n" .
					"Upgrade-Insecure-Requests: 1" .
					"User-Agent: Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36\r\n" .
					"Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8\r\n".
					"Connection: close"
					)
);
$konteks = stream_context_create($hed);
$img = "https://www.google.co.id/images/branding/googlelogo/1x/googlelogo_color_272x92dp.png";
$img = $_SERVER['QUERY_STRING'];
file_put_contents("one.png", fopen($img, 'r',false,$konteks));
$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, 'http://oreki00.pythonanywhere.com/uploader');
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_SAFE_UPLOAD, false);
$postData = array(
	'submit' => 'Submit',
	'file' => '@'.getcwd().'/one.png'
);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

$response = curl_exec($ch);
?>