function kanten(isi_kanten){
	max_kotoba = 120;
	kotoba_kanten=String.fromCharCode(isi_kanten.charCodeAt(0)+1)+isi_kanten.substring(1,);
	if(kotoba_kanten.charCodeAt(0)>max_kotoba){
		kotoba_kanten="a"+String.fromCharCode(isi_kanten.charCodeAt(1)+1)+isi_kanten.substring(2,);
	}
	if(kotoba_kanten.length>2){
		for(i_kanten=1;i_kanten<kotoba_kanten.length-1;i_kanten++){
			if(kotoba_kanten.charCodeAt(i_kanten)>max_kotoba){
				kotoba_kanten=kotoba_kanten.substring(0,i_kanten)+"a"+kotoba_kanten[i_kanten+1]+kotoba_kanten.substring(i_kanten+2);
			}
			console.log(kotoba_kanten);
			if((kotoba_kanten[i_kanten-1]==kotoba_kanten[i_kanten])&&(kotoba_kanten[i_kanten]==kotoba_kanten[i_kanten+1])){
				kotoba_kanten=kotoba_kanten.substring(0,i_kanten-1)+String.fromCharCode(kotoba_kanten.charCodeAt(i_kanten-1)+1)+kotoba_kanten.substring(i_kanten);
			}
		}
	}
	if(kotoba_kanten.charCodeAt(kotoba_kanten.length-1)>max_kotoba){
		kotoba_kanten=kotoba_kanten.substring(0,kotoba_kanten.length-1)+"a";
	}
	return kotoba_kanten;
}
alert(kanten("ssadasss"));