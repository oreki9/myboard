<?php
$url = "http://localhost/game/index.html";
if(isset($_GET['url'])){
	$url = $_GET['url'];
}
if(isset($_GET['add'])){
	$add = $_GET['add'];
}
if(isset($_GET['line'])){
	$line = $_GET['line'];
}
$step=1;
if(isset($_GET['step'])){
	$step = $_GET['step'];
}
function isi_script_kanten($html){
	if(substr($html,0,2)=="//"){
		$html = "http:".$html;
	}
	if(substr($html,0,1)=="/"){
		$html = substr($GLOBALS['url'],0,strripos($GLOBALS['url'], '/')).$html;
	}
	if((substr($html,0,4)!="http")){
		$html = substr($GLOBALS['url'],0,strripos($GLOBALS['url'], '/')+1).$html;
	}
	$hed = array(
	'http' => array(
		'method' => "GET",
		'header' => "Accept-Language: en-US,en;q=0.9\r\n" .
					"Cache-Control: max-age=0\r\n".
					"Cookie: foo=bar\r\n" .
					"Upgrade-Insecure-Requests: 1" .
					"User-Agent: Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36\r\n" .
					"Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8\r\n".
					"Connection: close"
					)
	);
	$konteks = stream_context_create($hed);
	$loe = file_get_contents($html, false, $konteks);
	return $loe;
}
$loe = isi_script_kanten($url);
$source_kanten = array(1=>"location",2=>"document.URL",3=>"document.documentURI",4=>"document.baseURI",5=>"document.cookie",6=>"document.referrer",7=>"XMLHttpRequest",8=>"$.ajax",9=>"$.get",10=>"$.post",11=>"fetch(",12=>"axios");
function isi_html($html,$awal,$akhir){
	return substr($html,$awal,$akhir-$awal);
}
function cari_script_kanten($html,$name){
	$source_kanten = $GLOBALS['source_kanten'];
	for ($i = 1; $i < count($source_kanten); $i++) {
		$lastPos = 0;
		$positions = array();
		$banyak=0;
		while (($lastPos = stripos($html, $source_kanten[$i], $lastPos))!== false) {
			if($banyak==3){
				break;
			}
			$banyak+=1;
			$positions[] = $lastPos;
			$lastPos = $lastPos + strlen($source_kanten[$i]);
		}
		foreach ($positions as $value) {
			echo $value ." ".$source_kanten[$i]." ".$name."</br>";
		}
	}
}
function cari_isi_script_kanten($html){
	$lastPos = 0;
	while (($lastPos = stripos($html, ".js", $lastPos))!== false) {
		$lastpos_last = stripos($html, '"', $lastPos);
		$lastpos_last2 = stripos($html, "'", $lastPos);
		if(strlen($lastpos_last)==0){
			$nama_script_kanten=isi_html($html,strripos(substr($html,0,$lastPos), "'", 0)+1,$lastpos_last2);
		}else if(strlen($lastpos_last2)==0){
			$nama_script_kanten=isi_html($html,strripos(substr($html,0,$lastPos), '"', 0)+1,$lastpos_last);
		}else if($lastpos_last>$lastpos_last2){
			$nama_script_kanten=isi_html($html,strripos(substr($html,0,$lastPos), "'", 0)+1,$lastpos_last2);
		}else if($lastpos_last2>$lastpos_last){
			$nama_script_kanten=isi_html($html,strripos(substr($html,0,$lastPos), '"', 0)+1,$lastpos_last);
		}
		cari_script_kanten(isi_script_kanten($nama_script_kanten),$nama_script_kanten);
		$lastPos = $lastPos + 3;
	}
}
function isi_kanten($html,$line,$step){
	$lastpos_first=$line;
	for ($i = 0; $i < $step; $i++) {
		$lastpos_first = strripos(substr($html,0,$lastpos_first-1), '{', 0);
	}
	$lastpos_last=$line;
	for ($i = 0; $i < $step; $i++) {
		$lastpos_last = stripos($html, '}', $lastpos_last+1);
	}
	return substr($html,$lastpos_first,$lastpos_last-$lastpos_first+1);
}
if(!isset($add)){
	cari_script_kanten($loe,"main");
	cari_isi_script_kanten($loe);
}else{
	if($add=="isi"){
		if(isset($line)){
			echo "<textarea>";
			echo isi_kanten($loe,$line,$step);
			echo "</textarea>";
		}
	}
}
?>