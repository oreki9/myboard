<?php
$end="";
if(isset($_GET['end'])){
	$end = $_GET['end'];
}
if(isset($_GET['url'])){
	$url = $_GET['url'];
}
if(isset($_GET['seed'])){
	$seed = $_GET['seed'];
}
if(isset($_GET['len'])){
	$len = $_GET['len'];
}else{
	$len = 1;
}
if(isset($_GET['att'])){
	$att = $_GET['att'];
}else{
	$att = "/";
}
$huruf = "abcdefghijklmnopqrstuvwxyz0123456789_-+=X";
$arrai = array("a"=>1,"b"=>2,"c"=>3,"d"=>4,"e"=>5,"f"=>6,
				"g"=>7,"h"=>8,"i"=>9,"j"=>10,"k"=>11,"l"=>12,
				"m"=>13,"n"=>14,"o"=>15,"p"=>16,"q"=>17,"r"=>18,
				"s"=>19,"t"=>20,"u"=>21,"v"=>22,"w"=>23,"x"=>24,
				"y"=>25,"z"=>26,"0"=>27,"1"=>28,"2"=>29,"3"=>30,
				"4"=>31,"5"=>32,"6"=>33,"7"=>34,"8"=>35,"9"=>36,
				"_"=>37,"-"=>38,"+"=>39,"="=>40,"X"=>41);
function kotoba($isi){
	$arai = array();
	$isi[0]=$GLOBALS['huruf'][$GLOBALS['arrai'][$isi[0]]];//menambah first word
	$panj = strlen($isi);
	for ($i = 0; $i < $panj; $i++) {
		if($GLOBALS['arrai'][$isi[$i]]>count($GLOBALS['arrai'])-1){
			if($i!=strlen($isi)-1){
				$isi[$i+1]=$GLOBALS['huruf'][$GLOBALS['arrai'][$isi[$i+1]]];
			}
			$isi[$i]=$GLOBALS['huruf'][0];
		}
		if($i<$panj-2){
			if(($isi[$i]==$isi[$i+1])&&($isi[$i+1]==$isi[$i+2])){
				$isi[$i]=$GLOBALS['huruf'][$GLOBALS['arrai'][$isi[$i]]];//menambah first word
				if($i>1){
					if(($isi[$i]==$isi[$i-1])&&($isi[$i-1]==$isi[$i-2])){
						$isi[$i-2]=$GLOBALS['huruf'][$GLOBALS['arrai'][$isi[$i-2]]];
					}
				}
			}
		}
	}
	return $isi;
}
$label = array();
$path = array();
for ($i = 0; $i < $len; $i++) {
	$seed = kotoba($seed);
	if($seed==$end){
		break;
	}
	$ch = curl_init($url.$seed.$att);
	curl_setopt($ch, CURLOPT_HEADER, true);
	curl_setopt($ch, CURLOPT_NOBODY, true);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
		"Accept-Language: en-US,en;q=0.9" ,
		"Cache-Control: max-age=0",
		"Cookie: foo=bar",
		"Upgrade-Insecure-Requests: 1",
		"User-Agent: Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36",
		"Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
		"Connection: close"
	));
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
	curl_setopt($ch, CURLOPT_TIMEOUT,10);
	$output = curl_exec($ch);
	$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	curl_close($ch);
	$jml_kata=round((strlen($output)+1)/100);
    $o=0;
    while(true){
		if(isset($label[$o][0])){//silent bug
			if($label[$o][0]==$httpcode){
				$e=0;
				while(true){
					if(isset($label[$o][1][$e])){//sillent bug
						if($label[$o][1][$e]==$jml_kata){
							array_push($path[$o][$e],$seed);
							break;
						}
					}
					if($e==count($label[$o][1])){
						array_push($label[$o][1],$jml_kata);
						$seed2 = array();
						array_push($seed2,$seed);
						array_push($path[$o],$seed2);
						break;
					}
					$e++;
				}
				if(!isset($path[$o][0])){
					$path[$o] = array();
				}
				break;
			}
		}
        if($o==count($label)){
            $label_i = array();
            $label_i[0]=$httpcode;
            $label_i[1]=array();
            array_push($label_i[1],$jml_kata);
            array_push($label,$label_i);
			$seed2 = array();
			array_push($seed2,$seed);
            if(!isset($path[$o][0])){
                $path[$o] = array();
            }
            array_push($path[$o],$seed2);
            break;
        }
        $o++;
    }
}
unset($label_i);
for ($i = 0; $i < count($path); $i++) {
	if(count($path[$i])>1){
		$label_i = array();
		$label_i[0] = count($path[$i][0]);
		$label_i[1] = 0;
		for ($o = 0; $o < count($path[$i]); $o++) {
			if(count($path[$i][$o])<$label_i[0]){
				$label_i[0] = count($path[$i][$o]);
				$label_i[1] = $o;
			}
		}
		print_r($path[$i][$label_i[1]]);
	}else{
		print_r($path[$i][0]);
	}
	echo "</br>";
}
echo "<img src=x onerror='alert(1)'>";
?>