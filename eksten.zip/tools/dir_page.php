<!DOCTYPE html>
<html>
<body>
<h2>Using the XMLHttpRequest Object</h2>
<div id="monitor1">
</div>
<script>
arai = [];
arai.push("Kiwi");
function loadXMLDoc(isi,end) {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
		document.getElementById("monitor1").innerHTML = this.responseText;
    }
  };
  xhttp.open("GET", "http://localhost/tools/dirpage.php?url=http://dinus.ac.id/androk/wismilak/slim/&seed="+isi+"&att=/index.html&len=4&end="+end, true);
  xhttp.send();
}
document.write(arai);
<?php
if(isset($_GET['isi'])){
	$isi = $_GET['isi'];
}
if(isset($_GET['end'])){
	$end = $_GET['end'];
}
if(isset($_GET['len'])){
	$len = $_GET['len'];
}
echo 'loadXMLDoc("'.$isi.'","'.$end.'");';
?>
</script>
</body>
</html>