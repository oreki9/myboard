source_kanten = ["location","document.URL","document.documentURI","document.baseURI","document.cookie","document.referrer","XMLHttpRequest","$.ajax","$.get","$.post","axios"];
function cari_script_kanten(){
	kanten_return = [];
	script_kanten = document.getElementsByTagName("script");
	for(i_kanten=0;i_kanten<script_kanten.length;i_kanten++){
		source_in_kanten = script_kanten[i_kanten];
		if(source_in_kanten.src){
			for(i_kanten2=0;i_kanten2<source_kanten.length;i_kanten2++){
				tempat_source_kanten = loadXMLDoc(source_in_kanten.src);
				tempat_source_kanten = (tempat_source_kanten).search(source_kanten[i_kanten2]);
				if((tempat_source_kanten)>0){
					kanten_return.push(source_kanten[i_kanten2]+" "+tempat_source_kanten+" "+source_in_kanten.src+" "+i_kanten);
					break;
				}
			}
		}else{
			for(i_kanten2=0;i_kanten2<source_kanten.length;i_kanten2++){
				tempat_source_kanten = (source_in_kanten.innerHTML).search(source_kanten[i_kanten2]);
				if((tempat_source_kanten)>0){
					kanten_return.push(source_kanten[i_kanten2]+" "+tempat_source_kanten+" main"+i_kanten);
					break;
				}
			}
		}
	}
	return kanten_return;
}
function loadXMLDoc(isi) {
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			return this.responseText;
		}
	};
	xhttp.open("GET", isi, true);
	xhttp.send();
}
cari_script_kanten();