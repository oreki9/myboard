// Copyright (c) 2012 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

'use strict';

function click() {
  chrome.tabs.executeScript(null,
      {file:"kanten.js"},receiveText);
}
click();
function receiveText(resultsArray){
    document.getElementById("naka").innerHTML = resultsArray[0];
}